
</div>
</div>
<!-- Footer Start -->
<footer class="footer-1"  id="footer">      
    <div class="vd_bottom ">
        <div class="container">
            <div class="row">
                <div class=" col-xs-12">
                    <div class="copyright col-xs-10">
                        Copyright &copy;2017 http://www.icanstudioz.com
                    </div>
                    <div class="col-sx-2">
                        Taxiapp (Version - 1.7)
                    </div>
                </div>
            </div><!-- row -->
        </div><!-- container -->
    </div>
</footer>
<!-- Footer END -->


<!-- .vd_body END  -->
<a id="back-top" href="#" data-action="backtop" style="background: none repeat scroll 0 0 #F9C30B" class="vd_back-top visible"> <i class="fa  fa-angle-up"> </i></a>

<!--
<a class="back-top" href="#" id="back-top"> <i class="icon-chevron-up icon-white"> </i> </a> -->

<!-- Javascript =============================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 

