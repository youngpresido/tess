<div class="content">
    <div class="container">
        <div class="vd_nav-width vd_navbar-tabs-menu vd_navbar-left" style="color:black;background-image:url('<?= $this->config->base_url() ?>avatar/bg.jpg')">
            <!--            <div class="navbar-tabs-menu clearfix">
                        </div>-->
            <div class="navbar-menu clearfix">
                <!--                <div class="vd_panel-menu hidden-xs">
                                    <span data-original-title="Expand All" data-toggle="tooltip" data-placement="bottom" data-action="expand-all" class="menu" data-intro="<strong>Expand Button</strong><br/>To expand all menu on left navigation menu." data-step=4 >
                                        <i class="fa fa-sort-amount-asc"></i>
                                    </span>                   
                                </div>-->
                <h3 class="menu-title hide-nav-medium hide-nav-small"></h3>
                <div class="vd_menu">

                    <ul>
                        <li>
                            <a style="color:black" href="<?php echo $this->config->base_url() ?>admin/index">
                                <span class="menu-icon"><i class="fa fa-map-marker"></i></span> 
                                <span class="menu-text" >Map</span>  

                            </a>
                        </li>
                        <li>
                            <a  style="color:black" href="<?php echo $this->config->base_url() ?>admin/users">
                                <span class="menu-icon"><i class="fa fa-users"></i></span> 
                                <span class="menu-text" style="color:black">Users</span>  

                            </a>
                        </li>
                        <li>
                            <a  style="color:black" href="<?php echo $this->config->base_url() ?>admin/drivers">
                                <span class="menu-icon"><i class="fa fa-user"></i></span> 
                                <span class="menu-text">Drivers</span>  

                            </a>
                        </li>
                        <li>
                            <a  style="color:black" href="<?php echo $this->config->base_url() ?>admin/getrides">
                                <span class="menu-icon"><i class="fa fa-taxi"></i></span> 
                                <span class="menu-text">Rides</span>  

                            </a>
                        </li>
                        <li>
                            <a  style="color:black" href="<?php echo $this->config->base_url() ?>admin/getPayments">
                                <span class="menu-icon"><i class="fa fa-suitcase"></i></span> 
                                <span class="menu-text">Payments</span>  

                            </a>
                        </li>
                        <li>
                            <a  style="color:black" href="<?php echo $this->config->base_url() ?>admin/settings">
                                <span class="menu-icon"><i class="fa fa-gears"></i></span> 
                                <span class="menu-text">settings</span>  

                            </a>
                        </li>
                        <li>
                            <a  style="color:black" href="<?php echo $this->config->base_url() ?>admin/logout">
                                <span class="menu-icon"><i class="fa fa-sign-out"></i></span> 
                                <span class="menu-text">Logout</span>  

                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="navbar-spacing clearfix">
            </div>
        </div>

